"""Root-level entrypoint for platforms that auto-detect `main:app` (Railpack, Railway, Unkey).

The real application lives in src/weather_api/. This shim puts `src/` on the import path so
the app runs without the package being pip-installed:

    uvicorn main:app --host 0.0.0.0 --port ${PORT:-8000}
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent / "src"))

from weather_api.main import app  # noqa: E402

__all__ = ["app"]
